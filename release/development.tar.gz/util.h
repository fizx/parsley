#include <stdio.h>

FILE* dex_fopen(char*, char*);