#ifndef DEXTER_H_INCLUDED
#define DEXTER_H_INCLUDED

#define DEX_BUF_SIZE 1024

#include "obstack.h"
#include <stdbool.h>
#include <libxslt/xslt.h>
#include <libxslt/xsltInternals.h>
#include <libxslt/transform.h>

#define obstack_chunk_alloc malloc
#define obstack_chunk_free free

static struct obstack dex_obstack;
static int dex_debug_mode = 0;
static bool dex_exslt_registered = false;
static char* last_dex_error;

#include <json/json.h>

typedef struct __compiled_dex {
 	char* raw_stylesheet;
	xsltStylesheetPtr stylesheet;
	char* error;
} compiled_dex;

typedef compiled_dex * dexPtr;

typedef struct __key_node {
	char* name;
	char* use;
	struct __key_node * next;
} key_node;

typedef key_node * keyPtr;

typedef struct __dex_context {
	struct printbuf * buf;
	struct printbuf * key_buf;
 	keyPtr keys;
	struct json_object * json;
	struct __dex_context * parent;
	char* tag;
	char* filter;
	char* expr;
	char* raw_expr;
	char* full_expr;
	char* name;
	char* magic;
	int array;
	int string;
} dex_context;

typedef dex_context * contextPtr;

void dex_free(dexPtr);
dexPtr dex_compile(char* dex, char* incl);

xmlDocPtr dex_parse_file(dexPtr, char*, boolean);
xmlDocPtr dex_parse_string(dexPtr, char*, size_t, boolean);
xmlDocPtr dex_parse_doc(dexPtr, xmlDocPtr);

void* dex_alloc(int);
void dex_collect();

static contextPtr dex_parsing_context;

static char* full_expr(contextPtr, char*);
static char* expr_join(char*, char*);
static char* inner_key_of(struct json_object *);
static char* inner_key_each(struct json_object *);
static void free_context(contextPtr);
static contextPtr init_context();
static contextPtr clone_context(contextPtr);
static contextPtr tagged_context(contextPtr, char*);

static contextPtr new_context(struct json_object *, struct printbuf *);
static contextPtr deeper_context(contextPtr, char*, struct json_object *);

static char* dex_key_tag(char* key);
static char* dex_key_filter(char* key);
static void __dex_recurse(contextPtr);
static char* filter_intersection(char*, char*);

static char* inner_key_of(struct json_object *);
static char* inner_key_each(struct json_object *);
	
#endif