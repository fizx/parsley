#include "dexter.h"

void dex_error(char* msg){
	last_dex_error = msg;
}