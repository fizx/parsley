#ifndef KSTRING_INCLUDED
#define KSTRING_INCLUDED
extern char* arepl(char*, char*, char*);
extern char* astrdup(char*);
extern char* astrcat(char*, char*);
extern char* astrcat3(char*, char*, char*);
extern char* astrcat4(char*, char*, char*, char*);
extern char* astrcat5(char*, char*, char*, char*, char*);
extern char* astrcat6(char*, char*, char*, char*, char*, char*);
extern char* astrcat7(char*, char*, char*, char*, char*, char*, char*);
extern char* astrcat8(char*, char*, char*, char*, char*, char*, char*, char*);
extern char* astrcat9(char*, char*, char*, char*, char*, char*, char*, char*, char*);
extern char* astrcat10(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);

#endif