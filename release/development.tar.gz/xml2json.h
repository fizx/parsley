#ifndef XML2JSON_H_INCLUDED
#define XML2JSON_H_INCLUDED

struct json_object * xml2json(xmlNodePtr);

#endif